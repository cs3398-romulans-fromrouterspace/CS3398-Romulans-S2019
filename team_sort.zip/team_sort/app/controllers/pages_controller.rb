class PagesController < ApplicationController
  def letsencrypt
    render html: 'f_yZ6NpUkRuE4rNBHS3jkpGd1k0OCD6EChmHA35C4qg.X0QHgIu6QAqvxLyJigQZ4Gjk3j67p4uzGb_gwyfn-JI'
  end
end
