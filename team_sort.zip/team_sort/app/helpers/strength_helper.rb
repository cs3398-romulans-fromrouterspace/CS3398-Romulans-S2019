module StrengthHelper
end
